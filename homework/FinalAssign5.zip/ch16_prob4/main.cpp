/* 
 * File:   main.cpp
 * Author: Leslie
 *
 * Created on May 2, 2016, 11:47 AM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

/*
 * 
 */
//template <class T>

template <class T>

T Total (T size) 
{
    int sum=0;
    int s;
    for (int i=0;i<size;i++)
    {
        cin >> s[i];
        sum+=s[i];
        
    }
    return sum;
}

int main(int argc, char** argv) {

  
    return 0;
}

