/* 
 * File:   ShiftSupervisor.cpp
 * Author: Ariana & Gilbert
 *
 * Created on June 1, 2016, 8:43 PM
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

