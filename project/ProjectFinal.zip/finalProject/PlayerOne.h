/* 
 * File:   PlayerOne.h
 * Author: Leslie Rodriguez
 *
 * Created on May 4, 2016, 11:20 PM
 */

#ifndef PLAYERONE_H
#define	PLAYERONE_H

using namespace std;
struct PlayerOne
{
	string name;
	int health;
	int lives;
	int level;
        int health2;
};

#endif	/* PLAYERONE_H */

